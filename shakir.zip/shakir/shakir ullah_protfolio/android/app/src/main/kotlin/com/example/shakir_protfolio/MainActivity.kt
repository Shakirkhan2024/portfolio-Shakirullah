package com.example.shakir_protfolio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
