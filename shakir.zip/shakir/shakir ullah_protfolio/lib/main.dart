import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:url_launcher/url_launcher.dart';

void main() => runApp(const MyPortfolioApp());

class MyPortfolioApp extends StatelessWidget {
  const MyPortfolioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'My Portfolio',
      theme: ThemeData(
        textTheme: GoogleFonts.poppinsTextTheme(),
        primarySwatch: Colors.blue,
      ),
      home: PortfolioHomePage(),
    );
  }
}

class PortfolioHomePage extends StatelessWidget {
  final String profilePicUrl = 'https://example.com/your_profile_picture.png'; // Replace with your profile picture URL

  final List<String> skills = ['Flutter', 'Dart', 'Firebase', 'UI/UX'];

  final List<Map<String, String>> projects = [
    {
      'title': 'To do-App',
      'description': 'A description of your project.',
      'url': 'https://github.com/your_project_1'
    },
    {
      'title': 'Countdown App',
      'description': 'This project is a simple countdown timer app built using Flutter. The app allows users to input a countdown duration and control the timer with "Start," "Stop," and "Reset" buttons. It features input validation to ensure the user enters a valid number, and the timer decreases every second until it reaches zero. The apps UI updates in real-time, showing the remaining time, and the buttons adjust based on the timer s state (running or stopped). The goal is to provide an easy-to-use and responsive countdown timer experience.',
      'url': 'https://github.com/your_project_2'
    },
  ];

   PortfolioHomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Portfolio'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Profile Section
            const Center(
              child: CircleAvatar(
                radius: 60.0,
             backgroundImage: AssetImage('resources/images/shk.jpg'),
              ),
            ),
            const SizedBox(height: 20.0),
            const Center(
              child: Text(
                'Shakir Ullah',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
            ),
            const Center(
              child: Text(
                'Flutter Developer',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            ),
            const SizedBox(height: 30.0),

            // Skills Section
            const Text(
              'Skills',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10.0),
            Wrap(
              spacing: 8.0,
              children: skills
                  .map((skill) => Chip(
                        label: Text(skill),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 30.0),

            // Projects Section
            const Text(
              'Projects',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10.0),
            Column(
              children: projects
                  .map((project) => Card(
                        child: ListTile(
                          title: Text(project['title']!),
                          subtitle: Text(project['description']!),
                          trailing: IconButton(
                            icon: const Icon(Icons.open_in_new),
                            onPressed: () async {
                              if (await canLaunch(project['url']!)) {
                                await launch(project['url']!);
                              }
                            },
                          ),
                        ),
                      ))
                  .toList(),
            ),
            const SizedBox(height: 30.0),

            // Contact Section
            const Text(
              'Contact',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10.0),
            const Row(
              children: [
                Icon(Icons.email),
                SizedBox(width: 10.0),
                Text('Shakirkhansaib123456@gmail.com'),
              ],
            ),
            const SizedBox(height: 10.0),
            const Row(
              children: [
                Icon(Icons.phone),
                SizedBox(width: 10.0),
                Text('+3469019079'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}